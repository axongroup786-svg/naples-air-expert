import { NextResponse } from "next/server";

const ALLOWED_SERVICES = new Set([
  "AC Repair",
  "AC Installation",
  "AC Replacement",
  "AC Maintenance",
  "Emergency AC Repair",
  "Heating & Furnace Repair",
  "Heat Pump Services",
  "Duct Cleaning",
  "Ductwork Repair & Installation",
  "Indoor Air Quality",
  "Thermostat Installation",
  "Commercial HVAC",
  "Other / Not Sure",
]);

export async function POST(req: Request) {
  let body: Record<string, unknown>;
  try {
    body = (await req.json()) as Record<string, unknown>;
  } catch {
    return NextResponse.json({ ok: false, message: "Invalid request body." }, { status: 400 });
  }

  const str = (v: unknown) => (typeof v === "string" ? v.trim() : "");

  const name = str(body.name);
  const phone = str(body.phone);
  const email = str(body.email);
  const service = str(body.service);
  const propertyType = str(body.propertyType) || "Residential";
  const message = str(body.message);
  const source = str(body.source) || "website";
  const page = str(body.page) || "/";

  const errors: string[] = [];
  if (name.length < 2 || name.length > 120) errors.push("Name is required.");
  if (phone.replace(/\D/g, "").length < 10) errors.push("A valid phone number is required.");
  if (email && !/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email)) errors.push("Email is invalid.");
  if (message.length > 2000) errors.push("Message is too long.");
  if (!["Residential", "Commercial"].includes(propertyType))
    errors.push("Property type is invalid.");

  if (errors.length) {
    return NextResponse.json({ ok: false, message: errors.join(" ") }, { status: 422 });
  }

  const record = {
    name: name.slice(0, 120),
    phone: phone.slice(0, 32),
    email: email ? email.slice(0, 160) : null,
    service: (ALLOWED_SERVICES.has(service) ? service : "Other / Not Sure").slice(0, 120),
    propertyType,
    message: message ? message.slice(0, 2000) : null,
    source: source.slice(0, 80),
    page: page.slice(0, 400),
    receivedAt: new Date().toISOString(),
  };

  // 1) Primary: PostgreSQL via Drizzle (lazy import so a missing DATABASE_URL
  //    never crashes the module — important on serverless/static hosts).
  let saved = false;
  if (process.env.DATABASE_URL) {
    try {
      const [{ db }, { leads }] = await Promise.all([
        import("@/db"),
        import("@/db/schema"),
      ]);
      await db.insert(leads).values({
        name: record.name,
        phone: record.phone,
        email: record.email,
        service: record.service,
        propertyType: record.propertyType,
        message: record.message,
        source: record.source,
        page: record.page,
      });
      saved = true;
    } catch (err) {
      console.error("[lead] database insert failed", err);
    }
  }

  // 2) Fallback: webhook (Formspree / Make / Zapier / Apps Script) so no lead is
  //    lost when the host has no reachable Postgres (e.g. Cloudflare Workers).
  if (!saved && process.env.LEAD_WEBHOOK_URL) {
    try {
      const res = await fetch(process.env.LEAD_WEBHOOK_URL, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(record),
      });
      if (res.ok) saved = true;
      else console.error("[lead] webhook returned", res.status);
    } catch (err) {
      console.error("[lead] webhook failed", err);
    }
  }

  if (!saved) {
    // Degrade gracefully: the visitor still gets a clear next step.
    return NextResponse.json(
      {
        ok: false,
        message:
          "We could not log your request online right now. Please call (239) 765-4321 and we will help you directly.",
      },
      { status: 500 },
    );
  }

  return NextResponse.json({
    ok: true,
    message:
      "Your request is logged. A Naples Air Experts coordinator will call you back shortly at the number you provided.",
  });
}
