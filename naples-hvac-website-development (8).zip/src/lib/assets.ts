/**
 * Bundled image assets.
 *
 * Importing images as modules lets Next.js (Turbopack) emit them as hashed
 * files into the build output (`.next/static/media/`). This is required for
 * static hosts such as Netlify and Cloudflare Pages, which publish the build
 * output directory — string paths into `public/` are NOT copied there by the
 * Turbopack build and would 404 on those hosts.
 */
import commercialRooftopImg from "../assets/images/commercial-rooftop.jpg";
import ductworkImg from "../assets/images/ductwork.jpg";
import heroTechnicianImg from "../assets/images/hero-technician.jpg";
import thermostatImg from "../assets/images/thermostat.jpg";
import vanPanelImg from "../assets/images/van-panel.jpg";

/** Normalize a Next static-image import (string or StaticImageData) to a URL string. */
const url = (v: unknown): string =>
  typeof v === "string" ? v : String((v as { src?: unknown }).src ?? "");

export const ASSETS = {
  commercialRooftop: url(commercialRooftopImg),
  ductwork: url(ductworkImg),
  heroTechnician: url(heroTechnicianImg),
  thermostat: url(thermostatImg),
  vanPanel: url(vanPanelImg),
} as const;

export type AssetKey = keyof typeof ASSETS;
